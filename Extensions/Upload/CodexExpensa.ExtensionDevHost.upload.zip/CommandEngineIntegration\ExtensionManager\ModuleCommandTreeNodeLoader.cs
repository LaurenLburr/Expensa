using CodexExpensa.ExtensionDevHost.CommandEngineIntegration.Websites;

namespace CodexExpensa.ExtensionDevHost.CommandEngineIntegration.ExtensionManager;

public sealed class ModuleCommandTreeNodeLoader : IExtensionTreeNodeLoader
{
    private readonly ExtensionTreeContributionDescriptor _descriptor;
    private readonly HostWebsiteTreeContributionLoader _websiteContributionLoader;

    public ModuleCommandTreeNodeLoader(
        ExtensionTreeContributionDescriptor descriptor)
        : this(descriptor, new HostWebsiteTreeContributionLoader())
    {
    }

    public ModuleCommandTreeNodeLoader(
        ExtensionTreeContributionDescriptor descriptor,
        HostWebsiteTreeContributionLoader websiteContributionLoader)
    {
        ArgumentNullException.ThrowIfNull(descriptor);
        ArgumentNullException.ThrowIfNull(websiteContributionLoader);

        _descriptor = descriptor;
        _websiteContributionLoader = websiteContributionLoader;
    }

    public string AddinId =>
        _descriptor.AddinId;

    public string DisplayName =>
        _descriptor.DisplayName;

    public int SortOrder =>
        _descriptor.SortOrder;

    public async Task LoadNodeAsync(
        TreeView treeView,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(treeView);

        if (string.Equals(
                _descriptor.CommandName,
                "websites.load",
                StringComparison.OrdinalIgnoreCase))
        {
            await _websiteContributionLoader.LoadContributionAsync(
                treeView,
                new HostWebsiteTreeLoadOptions
                {
                    SearchText = string.Empty,
                    IncludeDisabled = false,
                    MaximumRows = 500,
                    ExpandAll = false
                },
                cancellationToken).ConfigureAwait(true);

            return;
        }

        throw new InvalidOperationException(
            $"No host tree contribution adapter is registered for command '{_descriptor.CommandName}'.");
    }
}
