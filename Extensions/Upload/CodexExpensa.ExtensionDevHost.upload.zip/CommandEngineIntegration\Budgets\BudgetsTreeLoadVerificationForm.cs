using CodexExpensa.ExtensionDevHost.CommandEngineIntegration.ExtensionManager;
using CodexExpensa.ExtensionDevHost.CommandEngineIntegration.Templates;
using Microsoft.Data.Sqlite;
using System.Data;
using System.Globalization;

namespace CodexExpensa.ExtensionDevHost.CommandEngineIntegration.Budgets;

public sealed partial class BudgetsTreeLoadVerificationForm : TreeTestTemplate
{
    private const string AddinId = "BudgetsAddin";
    private const int MaximumRows = 500;
    private const string BudgetMonthHierarchyQueryName = "Budgets.SelectBudgetMonthHierarchy";

    private readonly HostBudgetTreeContributionLoader _loader = new();
    private readonly HostBudgetRuntimeDatabaseSelectionService _databaseSelectionService = new();

    private string _databasePath = string.Empty;
    private bool _hasAutoLoaded;
    private AddinMemoryDatabaseSession? _databaseSession;

    public BudgetsTreeLoadVerificationForm()
    {
        InitializeComponent();
        ConfigureTreeTestTemplate(
            "Budgets Tree Load Verification",
            "Loading Budgets add-in runtime tree...");

        SafeDataGridViewBinding.Attach(ResultGrid);
        TestTreeView.AfterSelect += TestTreeView_AfterSelect;
    }

    protected override async void OnShown(EventArgs e)
    {
        base.OnShown(e);

        if (_hasAutoLoaded)
        {
            return;
        }

        _hasAutoLoaded = true;
        await LoadBudgetsTreeAsync().ConfigureAwait(true);
    }

    private async Task LoadBudgetsTreeAsync()
    {
        ClearTemplate();
        _databasePath = ResolveActiveRuntimeDatabasePath();

        if (string.IsNullOrWhiteSpace(_databasePath) || !File.Exists(_databasePath))
        {
            SetNotes(
                "Budgets add-in runtime database was not found." + Environment.NewLine + Environment.NewLine +
                "Expected add-in runtime path:" + Environment.NewLine +
                _databasePath + Environment.NewLine + Environment.NewLine +
                "Use the Budgets Database page to update data from Prod or Dev, then reload this tree test page.");
            SetGridData((object?)null);
            return;
        }

        SetNotes(
            "Loading Budgets from add-in runtime database:" + Environment.NewLine +
            _databasePath);

        try
        {
            HostBudgetTreeLoadResult result =
                await _loader.LoadContributionAsync(
                    TestTreeView,
                    new HostBudgetTreeLoadOptions
                    {
                        ExpandAll = true,
                        MaximumRows = MaximumRows
                    }).ConfigureAwait(true);

            ReloadMemoryDatabase();

            SetNotes(
                $"{result.ExecutionResult.Status}: {result.RootNodeCount} root node(s).{Environment.NewLine}" +
                result.ExecutionResult.Message + Environment.NewLine + Environment.NewLine +
                "Database is loaded into memory from:" + Environment.NewLine +
                _databasePath);

            SelectFirstBudgetNode();
        }
        catch (Exception exception)
        {
            ReleaseMemoryDatabase();
            SetGridData((object?)null);
            SetNotes(exception.ToString());

            MessageBox.Show(
                this,
                exception.Message,
                "Budgets Tree Load Verification",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }

    private void TestTreeView_AfterSelect(
        object? sender,
        TreeViewEventArgs e)
    {
        if (e.Node is null)
        {
            SetNotes(string.Empty);
            SetGridData((object?)null);
            return;
        }

        LoadBudgetMonthRowsForSelectedBudget(e.Node);
    }

    private void LoadBudgetMonthRowsForSelectedBudget(TreeNode selectedNode)
    {
        ArgumentNullException.ThrowIfNull(selectedNode);

        if (selectedNode.Tag is not HostBudgetTreeNodePayload payload)
        {
            SetGridData((object?)null);
            SetNotes(
                "Selected node does not contain a Budgets payload." + Environment.NewLine + Environment.NewLine +
                FormatSelectedNode(selectedNode));
            return;
        }

        try
        {
            BudgetMonthQueryResult queryResult =
                LoadMatchingBudgetMonthRows(GetMemoryConnection(), payload);

            DataTable hierarchyRows =
                CreateHierarchyGridTable(
                    SafeDataGridViewBinding.Sanitize(
                        queryResult.Rows));

            SetHierarchicalGridData(
                hierarchyRows,
                "__NodeId",
                "__ParentNodeId",
                expandAll: true);

            HideHierarchyIdentityColumns();

            SetNotes(
                $"Selected budget: {selectedNode.Text}{Environment.NewLine}" +
                $"Node type: {payload.NodeType}{Environment.NewLine}" +
                $"BudgetYear: {payload.BudgetYear}{Environment.NewLine}" +
                $"BudgetMonth: {payload.BudgetMonth}{Environment.NewLine}" +
                $"MonthKey: {payload.MonthKey}{Environment.NewLine}" + Environment.NewLine +
                "Budget rows are loaded as expandable parent nodes. Matching transactions are child nodes in the Krypton TreeGridView." + Environment.NewLine +
                "The budget selection matches only BudgetMonthRow.BudgetMonthId. Transactions are associated by matching BudgetMonthRow.Name to Payee.PayeeName and by the selected budget year/month." + Environment.NewLine +
                "SQL query used:" + Environment.NewLine +
                queryResult.Sql + Environment.NewLine + Environment.NewLine +
                "SQL parameters:" + Environment.NewLine +
                queryResult.Parameters + Environment.NewLine + Environment.NewLine +
                "Database is loaded into memory from:" + Environment.NewLine +
                _databasePath + Environment.NewLine +
                "The source database file is closed after the memory load completes." + Environment.NewLine +
                $"Grid rows shown: {queryResult.Rows.Rows.Count}");
        }
        catch (Exception exception)
        {
            SetGridData((object?)null);
            SetNotes(exception.ToString());
        }
    }

    private static DataTable CreateHierarchyGridTable(
        DataTable source)
    {
        ArgumentNullException.ThrowIfNull(source);

        DataColumn? rowTypeColumn =
            FindColumn(
                source,
                "RowType",
                "HierarchyRowType",
                "NodeType",
                "RecordType");

        DataColumn? budgetRowIdColumn =
            FindColumn(
                source,
                "BudgetMonthRowId",
                "BudgetRowId",
                "ParentId");

        DataColumn? transactionIdColumn =
            FindColumn(
                source,
                "TransactionId",
                "TxnId",
                "ChildId");

        if (rowTypeColumn is null ||
            budgetRowIdColumn is null)
        {
            throw new InvalidOperationException(
                "The Budget hierarchy query must return RowType and BudgetMonthRowId columns.");
        }

        DataTable hierarchy =
            source.Copy();

        hierarchy.Columns.Add(
            "__NodeId",
            typeof(string));

        hierarchy.Columns.Add(
            "__ParentNodeId",
            typeof(string));

        int rowOrdinal = 0;

        foreach (DataRow row in hierarchy.Rows)
        {
            rowOrdinal++;

            string rowType =
                Convert.ToString(
                    row[rowTypeColumn.ColumnName],
                    CultureInfo.InvariantCulture)
                ?? string.Empty;

            string budgetRowId =
                Convert.ToString(
                    row[budgetRowIdColumn.ColumnName],
                    CultureInfo.InvariantCulture)
                ?? string.Empty;

            bool isTransaction =
                rowType.Contains(
                    "Transaction",
                    StringComparison.OrdinalIgnoreCase)
                ||
                rowType.Contains(
                    "Child",
                    StringComparison.OrdinalIgnoreCase);

            if (!isTransaction)
            {
                row["__NodeId"] =
                    CreateBudgetNodeId(
                        budgetRowId,
                        rowOrdinal);

                row["__ParentNodeId"] =
                    DBNull.Value;

                continue;
            }

            string transactionId =
                transactionIdColumn is null
                    ? string.Empty
                    : Convert.ToString(
                          row[transactionIdColumn.ColumnName],
                          CultureInfo.InvariantCulture)
                      ?? string.Empty;

            row["__NodeId"] =
                CreateTransactionNodeId(
                    transactionId,
                    rowOrdinal);

            row["__ParentNodeId"] =
                CreateBudgetNodeId(
                    budgetRowId,
                    rowOrdinal);
        }

        return hierarchy;
    }

    private static string CreateBudgetNodeId(
        string budgetRowId,
        int fallbackOrdinal)
    {
        return string.IsNullOrWhiteSpace(budgetRowId)
            ? $"budget-row:{fallbackOrdinal}"
            : $"budget-row:{budgetRowId}";
    }

    private static string CreateTransactionNodeId(
        string transactionId,
        int fallbackOrdinal)
    {
        return string.IsNullOrWhiteSpace(transactionId)
            ? $"transaction:{fallbackOrdinal}"
            : $"transaction:{transactionId}";
    }

    private void HideHierarchyIdentityColumns()
    {
        HideHierarchyColumn("__NodeId");
        HideHierarchyColumn("__ParentNodeId");
    }

    private void HideHierarchyColumn(string columnName)
    {
        if (HierarchyGrid.Columns.Contains(columnName))
        {
            HierarchyGrid.Columns[columnName]!.Visible = false;
        }
    }

    private static DataColumn? FindColumn(
        DataTable table,
        params string[] candidateNames)
    {
        foreach (string candidateName in candidateNames)
        {
            DataColumn? column =
                table.Columns
                    .Cast<DataColumn>()
                    .FirstOrDefault(
                        item =>
                            string.Equals(
                                item.ColumnName,
                                candidateName,
                                StringComparison.OrdinalIgnoreCase));

            if (column is not null)
            {
                return column;
            }
        }

        return null;
    }

    private SqliteConnection GetMemoryConnection()
    {
        if (_databaseSession is null)
        {
            ReloadMemoryDatabase();
        }

        return _databaseSession?.Connection
            ?? throw new InvalidOperationException("Budgets add-in database is not loaded into memory.");
    }

    private void ReloadMemoryDatabase()
    {
        ReleaseMemoryDatabase();
        _databaseSession = AddinMemoryDatabaseSession.LoadFromFile(_databasePath);
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        ReleaseMemoryDatabase();
        base.OnFormClosed(e);
    }

    private void ReleaseMemoryDatabase()
    {
        _databaseSession?.Dispose();
        _databaseSession = null;
    }

    private static BudgetMonthQueryResult LoadMatchingBudgetMonthRows(
        SqliteConnection connection,
        HostBudgetTreeNodePayload payload)
    {
        ArgumentNullException.ThrowIfNull(connection);
        ArgumentNullException.ThrowIfNull(payload);

        BudgetsSqlQueryCatalog catalog = new(connection);
        string sql = catalog.GetRequiredSqlText(BudgetMonthHierarchyQueryName);

        using SqliteCommand command = connection.CreateCommand();
        command.CommandText = sql;
        command.Parameters.AddWithValue(
            "@BudgetMonthId",
            string.IsNullOrWhiteSpace(payload.MonthKey)
                ? DBNull.Value
                : payload.MonthKey);

        string parameters = FormatParameters(command);
        DataTable rows = LoadDataTable(command);

        return new BudgetMonthQueryResult(rows, sql.Trim(), parameters);
    }

    private static string FormatParameters(SqliteCommand command)
    {
        List<string> lines = [];

        foreach (SqliteParameter parameter in command.Parameters)
        {
            lines.Add(
                parameter.ParameterName +
                " = " +
                Convert.ToString(parameter.Value, CultureInfo.InvariantCulture));
        }

        lines.Add("@MaximumRows = " + MaximumRows.ToString(CultureInfo.InvariantCulture));

        return lines.Count == 0
            ? "(none)"
            : string.Join(Environment.NewLine, lines);
    }

    private static DataTable LoadDataTable(SqliteCommand command)
    {
        command.Parameters.AddWithValue("@MaximumRows", MaximumRows);

        using SqliteDataReader reader =
            command.ExecuteReader();

        DataTable table = new();

        // Do not use DataTable.Load(reader) here. The hierarchy query returns one
        // BudgetMonthRow parent followed by zero or more transaction children.
        // That intentionally repeats BudgetMonthRowId. DataTable.Load can infer
        // the source primary-key/unique constraint and reject the child rows.
        for (int ordinal = 0; ordinal < reader.FieldCount; ordinal++)
        {
            table.Columns.Add(reader.GetName(ordinal), typeof(object));
        }

        table.BeginLoadData();

        try
        {
            while (reader.Read())
            {
                DataRow row = table.NewRow();

                for (int ordinal = 0; ordinal < reader.FieldCount; ordinal++)
                {
                    row[ordinal] = reader.IsDBNull(ordinal)
                        ? DBNull.Value
                        : reader.GetValue(ordinal);
                }

                table.Rows.Add(row);
            }
        }
        finally
        {
            table.EndLoadData();
        }

        return table;
    }

    private static DataTable CreateMessageTable(string message)
    {
        DataTable table = new();
        table.Columns.Add("Message", typeof(string));
        table.Rows.Add(message);
        return table;
    }

    private void SelectFirstBudgetNode()
    {
        TreeNode? budgetNode =
            FindFirstBudgetNode(TestTreeView.Nodes.Cast<TreeNode>());

        if (budgetNode is null)
        {
            SetGridData((object?)null);
            SetNotes(
                "Budgets tree loaded, but no BudgetMonth-backed node was found." + Environment.NewLine + Environment.NewLine +
                "Add-in DB:" + Environment.NewLine +
                _databasePath);
            return;
        }

        TestTreeView.SelectedNode = budgetNode;
        budgetNode.EnsureVisible();
    }

    private static TreeNode? FindFirstBudgetNode(IEnumerable<TreeNode> nodes)
    {
        foreach (TreeNode node in nodes)
        {
            if (node.Tag is HostBudgetTreeNodePayload payload &&
                !string.IsNullOrWhiteSpace(payload.MonthKey))
            {
                return node;
            }

            TreeNode? child =
                FindFirstBudgetNode(node.Nodes.Cast<TreeNode>());

            if (child is not null)
            {
                return child;
            }
        }

        return null;
    }

    private string ResolveActiveRuntimeDatabasePath()
    {
        HostBudgetDatabaseLocation location =
            _databaseSelectionService.GetActiveRuntimeDatabaseLocation();

        return location.DatabasePath;
    }

    private static string FormatSelectedNode(TreeNode node)
    {
        return
            $"Text: {node.Text}{Environment.NewLine}" +
            $"Name: {node.Name}{Environment.NewLine}" +
            $"Tag type: {node.Tag?.GetType().FullName ?? "(null)"}{Environment.NewLine}" +
            $"Tag:{Environment.NewLine}{Convert.ToString(node.Tag, CultureInfo.InvariantCulture)}";
    }

    private sealed record BudgetMonthQueryResult(
        DataTable Rows,
        string Sql,
        string Parameters);
}
