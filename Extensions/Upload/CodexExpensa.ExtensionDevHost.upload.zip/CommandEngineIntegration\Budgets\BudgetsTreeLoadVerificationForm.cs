using CodexExpensa.ExtensionDevHost.CommandEngineIntegration.Templates;
using System.Data;

namespace CodexExpensa.ExtensionDevHost.CommandEngineIntegration.Budgets;

public sealed partial class BudgetsTreeLoadVerificationForm : TreeTestTemplate
{
    private readonly HostBudgetTreeContributionLoader loader = new();

    public BudgetsTreeLoadVerificationForm()
    {
        InitializeComponent();
        ConfigureTreeTestTemplate(
            "Budgets Tree Load Verification",
            "Select a budget tree node to inspect its payload.");

        TestTreeView.AfterSelect += TestTreeView_AfterSelect;
    }

    protected override async void OnShown(EventArgs e)
    {
        base.OnShown(e);
        await LoadBudgetsTreeAsync().ConfigureAwait(true);
    }

    private async Task LoadBudgetsTreeAsync()
    {
        SetNotes("Loading Budgets tree...");
        SetGridData((object?)null);

        try
        {
            HostBudgetTreeLoadResult result =
                await loader.LoadContributionAsync(
                    TestTreeView,
                    new HostBudgetTreeLoadOptions
                    {
                        ExpandAll = true,
                        MaximumRows = 500
                    }).ConfigureAwait(true);

            SetNotes(
                $"{result.ExecutionResult.Status}: {result.RootNodeCount} root node(s).{Environment.NewLine}{result.ExecutionResult.Message}");
        }
        catch (Exception exception)
        {
            SetNotes(exception.ToString());

            MessageBox.Show(
                this,
                exception.Message,
                "Budgets Tree Load Verification",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }

    private void TestTreeView_AfterSelect(
        object? sender,
        TreeViewEventArgs e)
    {
        TreeNode? selectedNode = e.Node;

        if (selectedNode is null)
        {
            SetNotes(string.Empty);
            SetGridData((object?)null);
            return;
        }

        SetNotes(selectedNode.Tag?.ToString() ?? selectedNode.Text);
        SetGridData(BuildSelectedNodeGrid(selectedNode));
    }

    private static DataTable BuildSelectedNodeGrid(
        TreeNode selectedNode)
    {
        ArgumentNullException.ThrowIfNull(selectedNode);

        DataTable table = new("SelectedBudgetNode");
        table.Columns.Add("Property", typeof(string));
        table.Columns.Add("Value", typeof(string));

        AddRow(table, "Text", selectedNode.Text);
        AddRow(table, "FullPath", selectedNode.FullPath);
        AddRow(table, "ChildCount", selectedNode.Nodes.Count.ToString());
        AddRow(table, "TagType", selectedNode.Tag?.GetType().FullName ?? string.Empty);
        AddRow(table, "Tag", selectedNode.Tag?.ToString() ?? string.Empty);

        return table;
    }

    private static void AddRow(
        DataTable table,
        string property,
        string value)
    {
        DataRow row = table.NewRow();
        row["Property"] = property;
        row["Value"] = value;
        table.Rows.Add(row);
    }
}
