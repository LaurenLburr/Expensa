namespace CodexExpensa.ExtensionDevHost.CommandEngineIntegration.Websites;

public sealed class HostWebsiteCategoryGroupTreeNodePayload : IHostWebsiteTreeNodePayload
{
    public HostWebsiteTreeNodeType NodeType => HostWebsiteTreeNodeType.CategoryGroup;

    public required string NodeId { get; init; }

    public required string DisplayText { get; init; }

    public string WebsiteId => string.Empty;

    public string TagName => DisplayText;

    public string Url => string.Empty;

    public bool IsActive => true;
}
