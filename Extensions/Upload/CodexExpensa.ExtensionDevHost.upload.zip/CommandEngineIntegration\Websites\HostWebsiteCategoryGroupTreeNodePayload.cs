namespace CodexExpensa.ExtensionDevHost.CommandEngineIntegration.Websites;

public sealed class HostWebsiteCategoryGroupTreeNodePayload
{
    public required string NodeId { get; init; }

    public required string DisplayText { get; init; }
}
