namespace CodexExpensa.ExtensionDevHost.CommandEngineIntegration.Websites;

public interface IHostWebsiteTreeNodePayload
{
    string NodeId { get; }

    string WebsiteId { get; }

    string DisplayText { get; }

    string Url { get; }

    string TagName { get; }

    string NodeType { get; }

    bool IsActive { get; }
}
