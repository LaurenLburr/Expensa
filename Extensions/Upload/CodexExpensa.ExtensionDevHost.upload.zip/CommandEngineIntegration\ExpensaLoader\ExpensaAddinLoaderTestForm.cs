using CodexExpensa.ExtensionDevHost.CommandEngineIntegration.CommonTree;

namespace CodexExpensa.ExtensionDevHost.CommandEngineIntegration.ExpensaLoader;

public sealed class ExpensaAddinLoaderTestForm : Form
{
    private readonly ExpensaAddinTreeViewLoaderService treeLoader = new();

    private readonly ComboBox addinComboBox = new();
    private readonly TextBox databasePathTextBox = new();
    private readonly TextBox searchTextBox = new();
    private readonly CheckBox includeInactiveCheckBox = new();
    private readonly CheckBox expandAllCheckBox = new();
    private readonly NumericUpDown maximumRowsNumericUpDown = new();
    private readonly Button browseDatabaseButton = new();
    private readonly Button loadSelectedButton = new();
    private readonly Button loadAllButton = new();
    private readonly Label statusLabel = new();
    private readonly TreeView treeView = new();
    private readonly TextBox detailsTextBox = new();

    private bool hasAutoLoaded;

    public ExpensaAddinLoaderTestForm()
    {
        Text = "Expensa Add-in Loader Tree Test";
        Width = 1200;
        Height = 780;
        StartPosition = FormStartPosition.CenterParent;

        BuildLayout();
        LoadDefaults();

        AcceptButton = loadAllButton;
    }

    protected override async void OnShown(EventArgs e)
    {
        base.OnShown(e);

        if (hasAutoLoaded)
        {
            return;
        }

        hasAutoLoaded = true;

        await LoadAllAsync().ConfigureAwait(true);
    }

    private void BuildLayout()
    {
        TableLayoutPanel root = new()
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 4,
            Padding = new Padding(8)
        };

        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 90F));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 40F));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 28F));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));

        root.Controls.Add(BuildTopPanel(), 0, 0);
        root.Controls.Add(BuildCommandPanel(), 0, 1);

        statusLabel.Dock = DockStyle.Fill;
        statusLabel.Text = "Ready.";
        statusLabel.TextAlign = ContentAlignment.MiddleLeft;
        root.Controls.Add(statusLabel, 0, 2);

        SplitContainer split = new()
        {
            Dock = DockStyle.Fill,
            SplitterDistance = 430
        };

        treeView.Dock = DockStyle.Fill;
        treeView.AfterSelect += treeView_AfterSelect;

        detailsTextBox.Dock = DockStyle.Fill;
        detailsTextBox.Multiline = true;
        detailsTextBox.ReadOnly = true;
        detailsTextBox.ScrollBars = ScrollBars.Both;
        detailsTextBox.WordWrap = false;

        split.Panel1.Controls.Add(treeView);
        split.Panel2.Controls.Add(detailsTextBox);

        root.Controls.Add(split, 0, 3);

        Controls.Add(root);
    }

    private Control BuildTopPanel()
    {
        TableLayoutPanel layout = new()
        {
            Dock = DockStyle.Fill,
            ColumnCount = 4,
            RowCount = 2
        };

        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110F));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 220F));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100F));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));

        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 34F));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 34F));

        layout.Controls.Add(new Label { Text = "Add-in:", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 0);

        addinComboBox.Dock = DockStyle.Fill;
        addinComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
        addinComboBox.Items.Add("Websites");
        addinComboBox.Items.Add("Budgets");
        layout.Controls.Add(addinComboBox, 1, 0);

        browseDatabaseButton.Text = "Browse...";
        browseDatabaseButton.Dock = DockStyle.Fill;
        browseDatabaseButton.Click += browseDatabaseButton_Click;
        layout.Controls.Add(browseDatabaseButton, 2, 0);

        layout.Controls.Add(new Label { Text = "Database:", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 1);

        databasePathTextBox.Dock = DockStyle.Fill;
        layout.SetColumnSpan(databasePathTextBox, 3);
        layout.Controls.Add(databasePathTextBox, 1, 1);

        return layout;
    }

    private Control BuildCommandPanel()
    {
        FlowLayoutPanel panel = new()
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight
        };

        panel.Controls.Add(new Label { Text = "Search:", AutoSize = true, TextAlign = ContentAlignment.MiddleLeft });

        searchTextBox.Width = 220;
        panel.Controls.Add(searchTextBox);

        includeInactiveCheckBox.Text = "Include inactive/closed";
        includeInactiveCheckBox.AutoSize = true;
        panel.Controls.Add(includeInactiveCheckBox);

        expandAllCheckBox.Text = "Expand";
        expandAllCheckBox.AutoSize = true;
        expandAllCheckBox.Checked = true;
        panel.Controls.Add(expandAllCheckBox);

        panel.Controls.Add(new Label { Text = "Max:", AutoSize = true, TextAlign = ContentAlignment.MiddleLeft });

        maximumRowsNumericUpDown.Minimum = 1;
        maximumRowsNumericUpDown.Maximum = 100000;
        maximumRowsNumericUpDown.Value = 500;
        maximumRowsNumericUpDown.Width = 90;
        panel.Controls.Add(maximumRowsNumericUpDown);

        loadAllButton.Text = "Load All";
        loadAllButton.Width = 120;
        loadAllButton.Click += loadAllButton_Click;
        loadAllButton.Font = new Font(loadAllButton.Font, FontStyle.Bold);
        panel.Controls.Add(loadAllButton);

        loadSelectedButton.Text = "Load Selected";
        loadSelectedButton.Width = 130;
        loadSelectedButton.Click += loadSelectedButton_Click;
        panel.Controls.Add(loadSelectedButton);

        return panel;
    }

    private void LoadDefaults()
    {
        addinComboBox.SelectedIndex = 0;

        databasePathTextBox.Text =
            Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "CodexExpensa",
                "db",
                "codexexpensa.db");
    }

    private void browseDatabaseButton_Click(object? sender, EventArgs e)
    {
        using OpenFileDialog dialog =
            new()
            {
                Title = "Select Expensa database",
                Filter = "SQLite database (*.db)|*.db|All files (*.*)|*.*",
                FileName = databasePathTextBox.Text
            };

        if (dialog.ShowDialog(this) == DialogResult.OK)
        {
            databasePathTextBox.Text = dialog.FileName;
        }
    }

    private async void loadSelectedButton_Click(object? sender, EventArgs e)
    {
        await LoadSelectedAsync().ConfigureAwait(true);
    }

    private async void loadAllButton_Click(object? sender, EventArgs e)
    {
        await LoadAllAsync().ConfigureAwait(true);
    }

    private async Task LoadSelectedAsync()
    {
        SetLoadingState(true, "Loading selected add-in through Expensa-style aggregate tree loader...");

        try
        {
            IReadOnlyList<ExpensaAddinLoaderResult> results =
                await treeLoader.LoadIntoTreeViewAsync(
                    treeView,
                    new ExpensaAddinLoaderRequest
                    {
                        Kind = GetSelectedKind(),
                        SearchText = searchTextBox.Text.Trim(),
                        IncludeInactive = includeInactiveCheckBox.Checked,
                        MaximumRows = (int)maximumRowsNumericUpDown.Value,
                        DatabasePath = databasePathTextBox.Text.Trim()
                    },
                    expandAllCheckBox.Checked).ConfigureAwait(true);

            ShowResultStatus(results);
            SelectFirstMeaningfulNode();
        }
        catch (Exception exception)
        {
            ShowFailure(exception);
        }
        finally
        {
            SetLoadingState(false);
        }
    }

    private async Task LoadAllAsync()
    {
        SetLoadingState(true, "Loading Websites and Budgets under one Expensa Add-ins root...");

        try
        {
            IReadOnlyList<ExpensaAddinLoaderResult> results =
                await treeLoader.LoadAllIntoTreeViewAsync(
                    treeView,
                    new ExpensaAddinLoaderRequestTemplate
                    {
                        DatabasePath = databasePathTextBox.Text.Trim(),
                        SearchText = searchTextBox.Text.Trim(),
                        IncludeInactive = includeInactiveCheckBox.Checked,
                        MaximumRows = (int)maximumRowsNumericUpDown.Value
                    },
                    expandAllCheckBox.Checked).ConfigureAwait(true);

            ShowResultStatus(results);
            SelectFirstMeaningfulNode();
        }
        catch (Exception exception)
        {
            ShowFailure(exception);
        }
        finally
        {
            SetLoadingState(false);
        }
    }

    private void SelectFirstMeaningfulNode()
    {
        if (treeView.Nodes.Count == 0)
        {
            return;
        }

        TreeNode rootNode = treeView.Nodes[0];
        rootNode.Expand();

        if (rootNode.Nodes.Count > 0)
        {
            treeView.SelectedNode = rootNode.Nodes[0];
            treeView.SelectedNode.EnsureVisible();
            return;
        }

        treeView.SelectedNode = rootNode;
    }

    private void ShowResultStatus(IReadOnlyList<ExpensaAddinLoaderResult> results)
    {
        string loadedText =
            string.Join(" | ", results.Select(static result => $"{result.AddinName}: {result.Status} - {result.Message}"));

        statusLabel.Text = $"Loaded {results.Count} add-in(s): {loadedText}";
    }

    private void ShowFailure(Exception exception)
    {
        statusLabel.Text = "Failed.";
        detailsTextBox.Text = exception.ToString();

        MessageBox.Show(this, exception.Message, "Expensa Add-in Loader Tree Test", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }

    private void SetLoadingState(bool isLoading, string? message = null)
    {
        loadSelectedButton.Enabled = !isLoading;
        loadAllButton.Enabled = !isLoading;
        browseDatabaseButton.Enabled = !isLoading;

        if (!string.IsNullOrWhiteSpace(message))
        {
            statusLabel.Text = message;
        }
    }

    private ExpensaAddinLoaderKind GetSelectedKind()
    {
        return addinComboBox.SelectedItem?.ToString() switch
        {
            "Budgets" => ExpensaAddinLoaderKind.Budgets,
            _ => ExpensaAddinLoaderKind.Websites
        };
    }

    private void treeView_AfterSelect(object? sender, TreeViewEventArgs e)
    {
        detailsTextBox.Text = AddinTreeSelectionFormatter.FormatSelectedNode(treeView);
    }
}
