namespace CodexExpensa.ExtensionDevHost;

partial class MainForm
{
    private System.ComponentModel.IContainer components = null;

    private MenuStrip mainMenuStrip;
    private SplitContainer mainSplitContainer;
    private TreeView navigationTreeView;
    private Panel contentPanel;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components is not null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();

        mainMenuStrip = new MenuStrip();
        mainSplitContainer = new SplitContainer();
        navigationTreeView = new TreeView();
        contentPanel = new Panel();

        ((System.ComponentModel.ISupportInitialize)mainSplitContainer).BeginInit();
        mainSplitContainer.Panel1.SuspendLayout();
        mainSplitContainer.Panel2.SuspendLayout();
        mainSplitContainer.SuspendLayout();
        SuspendLayout();

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(1400, 900);
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Extension Dev Host";

        mainMenuStrip.Dock = DockStyle.Top;
        mainMenuStrip.Name = "mainMenuStrip";

        mainSplitContainer.Dock = DockStyle.Fill;
        mainSplitContainer.FixedPanel = FixedPanel.Panel1;
        mainSplitContainer.Name = "mainSplitContainer";
        mainSplitContainer.SplitterDistance = 320;

        navigationTreeView.Dock = DockStyle.Fill;
        navigationTreeView.HideSelection = false;
        navigationTreeView.Name = "navigationTreeView";
        navigationTreeView.AfterSelect += NavigationTreeView_AfterSelect;
        navigationTreeView.NodeMouseDoubleClick += NavigationTreeView_NodeMouseDoubleClick;

        contentPanel.Dock = DockStyle.Fill;
        contentPanel.Name = "contentPanel";

        mainSplitContainer.Panel1.Controls.Add(navigationTreeView);
        mainSplitContainer.Panel2.Controls.Add(contentPanel);

        Controls.Add(mainSplitContainer);
        Controls.Add(mainMenuStrip);

        MainMenuStrip = mainMenuStrip;

        mainSplitContainer.Panel1.ResumeLayout(false);
        mainSplitContainer.Panel2.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)mainSplitContainer).EndInit();
        mainSplitContainer.ResumeLayout(false);
        ResumeLayout(false);
        PerformLayout();
    }
}
