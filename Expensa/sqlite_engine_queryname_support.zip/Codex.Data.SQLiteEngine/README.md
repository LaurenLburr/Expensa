# Codex.Data.SQLiteEngine

Reusable C# SQLite engine project for .NET 8.

## Features

- Centralized SQLite execution wrapper
- Events for:
  - CommandExecuting
  - CommandExecuted
  - CommandFailed
  - TransactionBegan
  - TransactionCommitted
  - TransactionRolledBack
  - TransactionFailed
- Query name support for SQL catalog scenarios
- Methods for:
  - ExecuteNonQuery
  - ExecuteScalar
  - Query
  - QueryDataTable
  - BeginTransaction

## Basic usage

```csharp
using Codex.Data.SQLiteEngine;
using Microsoft.Data.Sqlite;

string connectionString = "Data Source=mydb.db";

ISqliteEngine engine = new SqliteEngine(connectionString);

engine.CommandExecuted += (_, e) =>
{
    Console.WriteLine($"QueryName={e.QueryName}; Sql={e.Sql}");
};

int rows = engine.ExecuteNonQuery(
    "UPDATE [Txn] SET [Status] = @Status WHERE [TransactionId] = @TransactionId;",
    new[]
    {
        new SqliteParameter("@Status", "Cleared"),
        new SqliteParameter("@TransactionId", 42)
    },
    queryName: "Txn.MarkCleared");
```
