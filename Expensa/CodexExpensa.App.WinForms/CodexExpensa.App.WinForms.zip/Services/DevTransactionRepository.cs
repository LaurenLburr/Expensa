﻿using CodexExpensa.Core.Domain.Transactions;

namespace CodexExpensa.App.WinForms.Services;

public sealed class DevTransactionRepository : ITransactionRepository
{
    private readonly List<Transaction> _transactions = new();

    private int _nextId = 1;

    public IReadOnlyList<Transaction> GetByAccountId(string accountId)
    {
        return _transactions
            .Where(t => t.AccountId == accountId)
            .ToList();
    }

    public void Add(Transaction txn)
    {
        Transaction stored = new()
        {
            TransactionId = _nextId++,
            AccountId = txn.AccountId,
            PayeeId = txn.PayeeId,
            Status = txn.Status,
            Amount = txn.Amount,
            StartDate = txn.StartDate,
            Confirm = txn.Confirm,
            Note = txn.Note
        };

        _transactions.Add(stored);
    }

    public void Update(Transaction txn)
    {
        int index = _transactions.FindIndex(t => t.TransactionId == txn.TransactionId);

        if (index < 0)
            return;

        _transactions[index] = txn;
    }

    public void Delete(int transactionId)
    {
        _transactions.RemoveAll(t => t.TransactionId == transactionId);
    }
}