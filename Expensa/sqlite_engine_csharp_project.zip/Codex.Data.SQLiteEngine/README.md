# Codex.Data.SQLiteEngine

Reusable C# SQLite engine project for .NET 8.

## Features

- Centralized SQLite execution wrapper
- Events for:
  - CommandExecuting
  - CommandExecuted
  - CommandFailed
- Methods for:
  - ExecuteNonQuery
  - ExecuteScalar
  - Query
  - QueryDataTable

## Basic usage

```csharp
using Codex.Data.SQLiteEngine;
using Microsoft.Data.Sqlite;

string connectionString = "Data Source=mydb.db";

ISqliteEngine engine = new SqliteEngine(connectionString);

engine.CommandFailed += (_, e) =>
{
    Console.WriteLine($"FAILED: {e.Sql}");
    Console.WriteLine(e.Exception?.Message);
};

int rows = engine.ExecuteNonQuery(
    "UPDATE [Txn] SET [Status] = @Status WHERE [TransactionId] = @TransactionId;",
    new[]
    {
        new SqliteParameter("@Status", "Cleared"),
        new SqliteParameter("@TransactionId", 42)
    });
```
