using Microsoft.Data.Sqlite;
using System.Data;

namespace Codex.Data.SQLiteEngine;

public sealed class SqliteEngine : ISqliteEngine
{
    private readonly string _connectionString;

    public event EventHandler<SqliteCommandEventArgs>? CommandExecuting;

    public event EventHandler<SqliteCommandEventArgs>? CommandExecuted;

    public event EventHandler<SqliteCommandEventArgs>? CommandFailed;

    public SqliteEngine(string connectionString)
    {
        if (string.IsNullOrWhiteSpace(connectionString))
            throw new ArgumentException("connectionString is required.", nameof(connectionString));

        _connectionString = connectionString;
    }

    public int ExecuteNonQuery(string sql, IReadOnlyList<SqliteParameter>? parameters = null)
    {
        ValidateSql(sql);

        DateTime startedUtc = DateTime.UtcNow;
        IReadOnlyList<SqliteParameterSnapshot> snapshot = CreateSnapshot(parameters);

        RaiseCommandExecuting(sql, snapshot, startedUtc);

        try
        {
            using SqliteConnection connection = CreateOpenConnection();
            using SqliteCommand command = CreateCommand(connection, sql, parameters);

            int rowsAffected = command.ExecuteNonQuery();

            RaiseCommandExecuted(sql, snapshot, startedUtc, rowsAffected, null);
            return rowsAffected;
        }
        catch (Exception ex)
        {
            RaiseCommandFailed(sql, snapshot, startedUtc, ex);
            throw;
        }
    }

    public T? ExecuteScalar<T>(string sql, IReadOnlyList<SqliteParameter>? parameters = null)
    {
        ValidateSql(sql);

        DateTime startedUtc = DateTime.UtcNow;
        IReadOnlyList<SqliteParameterSnapshot> snapshot = CreateSnapshot(parameters);

        RaiseCommandExecuting(sql, snapshot, startedUtc);

        try
        {
            using SqliteConnection connection = CreateOpenConnection();
            using SqliteCommand command = CreateCommand(connection, sql, parameters);

            object? rawResult = command.ExecuteScalar();
            T? result = ConvertScalar<T>(rawResult);

            RaiseCommandExecuted(sql, snapshot, startedUtc, null, rawResult);
            return result;
        }
        catch (Exception ex)
        {
            RaiseCommandFailed(sql, snapshot, startedUtc, ex);
            throw;
        }
    }

    public IReadOnlyList<T> Query<T>(
        string sql,
        Func<SqliteDataReader, T> map,
        IReadOnlyList<SqliteParameter>? parameters = null)
    {
        ValidateSql(sql);

        if (map is null)
            throw new ArgumentNullException(nameof(map));

        DateTime startedUtc = DateTime.UtcNow;
        IReadOnlyList<SqliteParameterSnapshot> snapshot = CreateSnapshot(parameters);

        RaiseCommandExecuting(sql, snapshot, startedUtc);

        try
        {
            using SqliteConnection connection = CreateOpenConnection();
            using SqliteCommand command = CreateCommand(connection, sql, parameters);
            using SqliteDataReader reader = command.ExecuteReader();

            List<T> results = new();

            while (reader.Read())
                results.Add(map(reader));

            RaiseCommandExecuted(sql, snapshot, startedUtc, results.Count, null);
            return results;
        }
        catch (Exception ex)
        {
            RaiseCommandFailed(sql, snapshot, startedUtc, ex);
            throw;
        }
    }

    public DataTable QueryDataTable(string sql, IReadOnlyList<SqliteParameter>? parameters = null)
    {
        ValidateSql(sql);

        DateTime startedUtc = DateTime.UtcNow;
        IReadOnlyList<SqliteParameterSnapshot> snapshot = CreateSnapshot(parameters);

        RaiseCommandExecuting(sql, snapshot, startedUtc);

        try
        {
            using SqliteConnection connection = CreateOpenConnection();
            using SqliteCommand command = CreateCommand(connection, sql, parameters);
            using SqliteDataReader reader = command.ExecuteReader();

            DataTable table = new();
            table.Load(reader);

            RaiseCommandExecuted(sql, snapshot, startedUtc, table.Rows.Count, null);
            return table;
        }
        catch (Exception ex)
        {
            RaiseCommandFailed(sql, snapshot, startedUtc, ex);
            throw;
        }
    }

    private SqliteConnection CreateOpenConnection()
    {
        SqliteConnection connection = new(_connectionString);
        connection.Open();
        return connection;
    }

    private static SqliteCommand CreateCommand(
        SqliteConnection connection,
        string sql,
        IReadOnlyList<SqliteParameter>? parameters)
    {
        SqliteCommand command = connection.CreateCommand();
        command.CommandText = sql;

        if (parameters is not null)
        {
            foreach (SqliteParameter parameter in parameters)
                command.Parameters.Add(parameter);
        }

        return command;
    }

    private static void ValidateSql(string sql)
    {
        if (string.IsNullOrWhiteSpace(sql))
            throw new ArgumentException("sql is required.", nameof(sql));
    }

    private void RaiseCommandExecuting(
        string sql,
        IReadOnlyList<SqliteParameterSnapshot> parameters,
        DateTime startedUtc)
    {
        CommandExecuting?.Invoke(this, new SqliteCommandEventArgs
        {
            Sql = sql,
            Parameters = parameters,
            StartedUtc = startedUtc,
            Duration = TimeSpan.Zero
        });
    }

    private void RaiseCommandExecuted(
        string sql,
        IReadOnlyList<SqliteParameterSnapshot> parameters,
        DateTime startedUtc,
        int? rowsAffected,
        object? scalarResult)
    {
        CommandExecuted?.Invoke(this, new SqliteCommandEventArgs
        {
            Sql = sql,
            Parameters = parameters,
            StartedUtc = startedUtc,
            Duration = DateTime.UtcNow - startedUtc,
            RowsAffected = rowsAffected,
            ScalarResult = scalarResult
        });
    }

    private void RaiseCommandFailed(
        string sql,
        IReadOnlyList<SqliteParameterSnapshot> parameters,
        DateTime startedUtc,
        Exception exception)
    {
        CommandFailed?.Invoke(this, new SqliteCommandEventArgs
        {
            Sql = sql,
            Parameters = parameters,
            StartedUtc = startedUtc,
            Duration = DateTime.UtcNow - startedUtc,
            Exception = exception
        });
    }

    private static IReadOnlyList<SqliteParameterSnapshot> CreateSnapshot(IReadOnlyList<SqliteParameter>? parameters)
    {
        if (parameters is null || parameters.Count == 0)
            return [];

        List<SqliteParameterSnapshot> snapshots = new(parameters.Count);

        foreach (SqliteParameter parameter in parameters)
        {
            snapshots.Add(new SqliteParameterSnapshot
            {
                Name = parameter.ParameterName,
                Value = parameter.Value,
                DbType = parameter.SqliteType.ToString()
            });
        }

        return snapshots;
    }

    private static T? ConvertScalar<T>(object? rawResult)
    {
        if (rawResult is null || rawResult is DBNull)
            return default;

        if (rawResult is T direct)
            return direct;

        Type targetType = Nullable.GetUnderlyingType(typeof(T)) ?? typeof(T);
        object converted = Convert.ChangeType(rawResult, targetType);
        return (T)converted;
    }
}
