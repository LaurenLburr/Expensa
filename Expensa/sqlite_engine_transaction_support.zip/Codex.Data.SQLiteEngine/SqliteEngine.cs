using Microsoft.Data.Sqlite;
using System.Data;

namespace Codex.Data.SQLiteEngine;

public sealed class SqliteEngine : ISqliteEngine
{
    private readonly string _connectionString;

    public event EventHandler<SqliteCommandEventArgs>? CommandExecuting;

    public event EventHandler<SqliteCommandEventArgs>? CommandExecuted;

    public event EventHandler<SqliteCommandEventArgs>? CommandFailed;

    public event EventHandler<SqliteTransactionEventArgs>? TransactionBegan;

    public event EventHandler<SqliteTransactionEventArgs>? TransactionCommitted;

    public event EventHandler<SqliteTransactionEventArgs>? TransactionRolledBack;

    public event EventHandler<SqliteTransactionEventArgs>? TransactionFailed;

    public SqliteEngine(string connectionString)
    {
        if (string.IsNullOrWhiteSpace(connectionString))
            throw new ArgumentException("connectionString is required.", nameof(connectionString));

        _connectionString = connectionString;
    }

    public int ExecuteNonQuery(string sql, IReadOnlyList<SqliteParameter>? parameters = null)
    {
        ValidateSql(sql);

        DateTime startedUtc = DateTime.UtcNow;
        IReadOnlyList<SqliteParameterSnapshot> snapshot = CreateSnapshot(parameters);

        RaiseCommandExecuting(sql, snapshot, startedUtc, false, null);

        try
        {
            using SqliteConnection connection = CreateOpenConnection();
            using SqliteCommand command = CreateCommand(connection, null, sql, parameters);

            int rowsAffected = command.ExecuteNonQuery();

            RaiseCommandExecuted(sql, snapshot, startedUtc, rowsAffected, null, false, null);
            return rowsAffected;
        }
        catch (Exception ex)
        {
            RaiseCommandFailed(sql, snapshot, startedUtc, ex, false, null);
            throw;
        }
    }

    public T? ExecuteScalar<T>(string sql, IReadOnlyList<SqliteParameter>? parameters = null)
    {
        ValidateSql(sql);

        DateTime startedUtc = DateTime.UtcNow;
        IReadOnlyList<SqliteParameterSnapshot> snapshot = CreateSnapshot(parameters);

        RaiseCommandExecuting(sql, snapshot, startedUtc, false, null);

        try
        {
            using SqliteConnection connection = CreateOpenConnection();
            using SqliteCommand command = CreateCommand(connection, null, sql, parameters);

            object? rawResult = command.ExecuteScalar();
            T? result = ConvertScalar<T>(rawResult);

            RaiseCommandExecuted(sql, snapshot, startedUtc, null, rawResult, false, null);
            return result;
        }
        catch (Exception ex)
        {
            RaiseCommandFailed(sql, snapshot, startedUtc, ex, false, null);
            throw;
        }
    }

    public IReadOnlyList<T> Query<T>(
        string sql,
        Func<SqliteDataReader, T> map,
        IReadOnlyList<SqliteParameter>? parameters = null)
    {
        ValidateSql(sql);

        if (map is null)
            throw new ArgumentNullException(nameof(map));

        DateTime startedUtc = DateTime.UtcNow;
        IReadOnlyList<SqliteParameterSnapshot> snapshot = CreateSnapshot(parameters);

        RaiseCommandExecuting(sql, snapshot, startedUtc, false, null);

        try
        {
            using SqliteConnection connection = CreateOpenConnection();
            using SqliteCommand command = CreateCommand(connection, null, sql, parameters);
            using SqliteDataReader reader = command.ExecuteReader();

            List<T> results = new();

            while (reader.Read())
                results.Add(map(reader));

            RaiseCommandExecuted(sql, snapshot, startedUtc, results.Count, null, false, null);
            return results;
        }
        catch (Exception ex)
        {
            RaiseCommandFailed(sql, snapshot, startedUtc, ex, false, null);
            throw;
        }
    }

    public DataTable QueryDataTable(string sql, IReadOnlyList<SqliteParameter>? parameters = null)
    {
        ValidateSql(sql);

        DateTime startedUtc = DateTime.UtcNow;
        IReadOnlyList<SqliteParameterSnapshot> snapshot = CreateSnapshot(parameters);

        RaiseCommandExecuting(sql, snapshot, startedUtc, false, null);

        try
        {
            using SqliteConnection connection = CreateOpenConnection();
            using SqliteCommand command = CreateCommand(connection, null, sql, parameters);
            using SqliteDataReader reader = command.ExecuteReader();

            DataTable table = new();
            table.Load(reader);

            RaiseCommandExecuted(sql, snapshot, startedUtc, table.Rows.Count, null, false, null);
            return table;
        }
        catch (Exception ex)
        {
            RaiseCommandFailed(sql, snapshot, startedUtc, ex, false, null);
            throw;
        }
    }

    public ISqliteTransactionScope BeginTransaction(IsolationLevel isolationLevel = IsolationLevel.Serializable)
    {
        DateTime startedUtc = DateTime.UtcNow;

        try
        {
            SqliteConnection connection = CreateOpenConnection();
            SqliteTransaction transaction = connection.BeginTransaction(isolationLevel);
            Guid transactionId = Guid.NewGuid();

            RaiseTransactionBegan(transactionId, startedUtc);

            return new SqliteTransactionScope(this, connection, transaction, transactionId, startedUtc);
        }
        catch (Exception ex)
        {
            RaiseTransactionFailed(Guid.NewGuid(), startedUtc, ex);
            throw;
        }
    }

    internal int ExecuteNonQueryInTransaction(
        SqliteConnection connection,
        SqliteTransaction transaction,
        Guid transactionId,
        string sql,
        IReadOnlyList<SqliteParameter>? parameters = null)
    {
        ValidateSql(sql);

        DateTime startedUtc = DateTime.UtcNow;
        IReadOnlyList<SqliteParameterSnapshot> snapshot = CreateSnapshot(parameters);

        RaiseCommandExecuting(sql, snapshot, startedUtc, true, transactionId);

        try
        {
            using SqliteCommand command = CreateCommand(connection, transaction, sql, parameters);
            int rowsAffected = command.ExecuteNonQuery();
            RaiseCommandExecuted(sql, snapshot, startedUtc, rowsAffected, null, true, transactionId);
            return rowsAffected;
        }
        catch (Exception ex)
        {
            RaiseCommandFailed(sql, snapshot, startedUtc, ex, true, transactionId);
            throw;
        }
    }

    internal T? ExecuteScalarInTransaction<T>(
        SqliteConnection connection,
        SqliteTransaction transaction,
        Guid transactionId,
        string sql,
        IReadOnlyList<SqliteParameter>? parameters = null)
    {
        ValidateSql(sql);

        DateTime startedUtc = DateTime.UtcNow;
        IReadOnlyList<SqliteParameterSnapshot> snapshot = CreateSnapshot(parameters);

        RaiseCommandExecuting(sql, snapshot, startedUtc, true, transactionId);

        try
        {
            using SqliteCommand command = CreateCommand(connection, transaction, sql, parameters);
            object? rawResult = command.ExecuteScalar();
            T? result = ConvertScalar<T>(rawResult);
            RaiseCommandExecuted(sql, snapshot, startedUtc, null, rawResult, true, transactionId);
            return result;
        }
        catch (Exception ex)
        {
            RaiseCommandFailed(sql, snapshot, startedUtc, ex, true, transactionId);
            throw;
        }
    }

    internal IReadOnlyList<T> QueryInTransaction<T>(
        SqliteConnection connection,
        SqliteTransaction transaction,
        Guid transactionId,
        string sql,
        Func<SqliteDataReader, T> map,
        IReadOnlyList<SqliteParameter>? parameters = null)
    {
        ValidateSql(sql);

        if (map is null)
            throw new ArgumentNullException(nameof(map));

        DateTime startedUtc = DateTime.UtcNow;
        IReadOnlyList<SqliteParameterSnapshot> snapshot = CreateSnapshot(parameters);

        RaiseCommandExecuting(sql, snapshot, startedUtc, true, transactionId);

        try
        {
            using SqliteCommand command = CreateCommand(connection, transaction, sql, parameters);
            using SqliteDataReader reader = command.ExecuteReader();

            List<T> results = new();

            while (reader.Read())
                results.Add(map(reader));

            RaiseCommandExecuted(sql, snapshot, startedUtc, results.Count, null, true, transactionId);
            return results;
        }
        catch (Exception ex)
        {
            RaiseCommandFailed(sql, snapshot, startedUtc, ex, true, transactionId);
            throw;
        }
    }

    internal DataTable QueryDataTableInTransaction(
        SqliteConnection connection,
        SqliteTransaction transaction,
        Guid transactionId,
        string sql,
        IReadOnlyList<SqliteParameter>? parameters = null)
    {
        ValidateSql(sql);

        DateTime startedUtc = DateTime.UtcNow;
        IReadOnlyList<SqliteParameterSnapshot> snapshot = CreateSnapshot(parameters);

        RaiseCommandExecuting(sql, snapshot, startedUtc, true, transactionId);

        try
        {
            using SqliteCommand command = CreateCommand(connection, transaction, sql, parameters);
            using SqliteDataReader reader = command.ExecuteReader();

            DataTable table = new();
            table.Load(reader);

            RaiseCommandExecuted(sql, snapshot, startedUtc, table.Rows.Count, null, true, transactionId);
            return table;
        }
        catch (Exception ex)
        {
            RaiseCommandFailed(sql, snapshot, startedUtc, ex, true, transactionId);
            throw;
        }
    }

    internal void RaiseTransactionCommitted(Guid transactionId, DateTime startedUtc)
    {
        TransactionCommitted?.Invoke(this, new SqliteTransactionEventArgs
        {
            TransactionId = transactionId,
            StartedUtc = startedUtc,
            Duration = DateTime.UtcNow - startedUtc
        });
    }

    internal void RaiseTransactionRolledBack(Guid transactionId, DateTime startedUtc)
    {
        TransactionRolledBack?.Invoke(this, new SqliteTransactionEventArgs
        {
            TransactionId = transactionId,
            StartedUtc = startedUtc,
            Duration = DateTime.UtcNow - startedUtc
        });
    }

    internal void RaiseTransactionFailed(Guid transactionId, DateTime startedUtc, Exception exception)
    {
        TransactionFailed?.Invoke(this, new SqliteTransactionEventArgs
        {
            TransactionId = transactionId,
            StartedUtc = startedUtc,
            Duration = DateTime.UtcNow - startedUtc,
            Exception = exception
        });
    }

    private SqliteConnection CreateOpenConnection()
    {
        SqliteConnection connection = new(_connectionString);
        connection.Open();
        return connection;
    }

    private static SqliteCommand CreateCommand(
        SqliteConnection connection,
        SqliteTransaction? transaction,
        string sql,
        IReadOnlyList<SqliteParameter>? parameters)
    {
        SqliteCommand command = connection.CreateCommand();
        command.CommandText = sql;
        command.Transaction = transaction;

        if (parameters is not null)
        {
            foreach (SqliteParameter parameter in parameters)
                command.Parameters.Add(parameter);
        }

        return command;
    }

    private static void ValidateSql(string sql)
    {
        if (string.IsNullOrWhiteSpace(sql))
            throw new ArgumentException("sql is required.", nameof(sql));
    }

    private void RaiseCommandExecuting(
        string sql,
        IReadOnlyList<SqliteParameterSnapshot> parameters,
        DateTime startedUtc,
        bool isInTransaction,
        Guid? transactionId)
    {
        CommandExecuting?.Invoke(this, new SqliteCommandEventArgs
        {
            Sql = sql,
            Parameters = parameters,
            StartedUtc = startedUtc,
            Duration = TimeSpan.Zero,
            IsInTransaction = isInTransaction,
            TransactionId = transactionId
        });
    }

    private void RaiseCommandExecuted(
        string sql,
        IReadOnlyList<SqliteParameterSnapshot> parameters,
        DateTime startedUtc,
        int? rowsAffected,
        object? scalarResult,
        bool isInTransaction,
        Guid? transactionId)
    {
        CommandExecuted?.Invoke(this, new SqliteCommandEventArgs
        {
            Sql = sql,
            Parameters = parameters,
            StartedUtc = startedUtc,
            Duration = DateTime.UtcNow - startedUtc,
            RowsAffected = rowsAffected,
            ScalarResult = scalarResult,
            IsInTransaction = isInTransaction,
            TransactionId = transactionId
        });
    }

    private void RaiseCommandFailed(
        string sql,
        IReadOnlyList<SqliteParameterSnapshot> parameters,
        DateTime startedUtc,
        Exception exception,
        bool isInTransaction,
        Guid? transactionId)
    {
        CommandFailed?.Invoke(this, new SqliteCommandEventArgs
        {
            Sql = sql,
            Parameters = parameters,
            StartedUtc = startedUtc,
            Duration = DateTime.UtcNow - startedUtc,
            Exception = exception,
            IsInTransaction = isInTransaction,
            TransactionId = transactionId
        });
    }

    private void RaiseTransactionBegan(Guid transactionId, DateTime startedUtc)
    {
        TransactionBegan?.Invoke(this, new SqliteTransactionEventArgs
        {
            TransactionId = transactionId,
            StartedUtc = startedUtc,
            Duration = TimeSpan.Zero
        });
    }

    private static IReadOnlyList<SqliteParameterSnapshot> CreateSnapshot(IReadOnlyList<SqliteParameter>? parameters)
    {
        if (parameters is null || parameters.Count == 0)
            return [];

        List<SqliteParameterSnapshot> snapshots = new(parameters.Count);

        foreach (SqliteParameter parameter in parameters)
        {
            snapshots.Add(new SqliteParameterSnapshot
            {
                Name = parameter.ParameterName,
                Value = parameter.Value,
                DbType = parameter.SqliteType.ToString()
            });
        }

        return snapshots;
    }

    private static T? ConvertScalar<T>(object? rawResult)
    {
        if (rawResult is null || rawResult is DBNull)
            return default;

        if (rawResult is T direct)
            return direct;

        Type targetType = Nullable.GetUnderlyingType(typeof(T)) ?? typeof(T);
        object converted = Convert.ChangeType(rawResult, targetType);
        return (T)converted;
    }
}
