# Codex.Data.SQLiteEngine

Reusable C# SQLite engine project for .NET 8.

## Features

- Centralized SQLite execution wrapper
- Events for:
  - CommandExecuting
  - CommandExecuted
  - CommandFailed
  - TransactionBegan
  - TransactionCommitted
  - TransactionRolledBack
  - TransactionFailed
- Methods for:
  - ExecuteNonQuery
  - ExecuteScalar
  - Query
  - QueryDataTable
  - BeginTransaction

## Basic usage

```csharp
using Codex.Data.SQLiteEngine;
using Microsoft.Data.Sqlite;

string connectionString = "Data Source=mydb.db";

ISqliteEngine engine = new SqliteEngine(connectionString);

using ISqliteTransactionScope tx = engine.BeginTransaction();

tx.ExecuteNonQuery(
    "INSERT INTO [Sample] ([Name], [Amount]) VALUES (@Name, @Amount);",
    new[]
    {
        new SqliteParameter("@Name", "alpha"),
        new SqliteParameter("@Amount", 42m)
    });

tx.Commit();
```
