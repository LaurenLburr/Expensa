using Microsoft.Data.Sqlite;
using System.Data;

namespace Codex.Data.SQLiteEngine;

public interface ISqliteTransactionScope : IDisposable
{
    Guid TransactionId { get; }

    int ExecuteNonQuery(string sql, IReadOnlyList<SqliteParameter>? parameters = null);

    T? ExecuteScalar<T>(string sql, IReadOnlyList<SqliteParameter>? parameters = null);

    IReadOnlyList<T> Query<T>(
        string sql,
        Func<SqliteDataReader, T> map,
        IReadOnlyList<SqliteParameter>? parameters = null);

    DataTable QueryDataTable(string sql, IReadOnlyList<SqliteParameter>? parameters = null);

    void Commit();

    void Rollback();
}
